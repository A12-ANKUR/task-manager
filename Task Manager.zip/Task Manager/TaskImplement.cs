﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using Newtonsoft.Json;

public class TaskManager
{
    private List<Task> tasks;
    private string filePath;

    public TaskManager(string filePath)
    {
        tasks = new List<Task>();
        this.filePath = filePath;
    }

    public void AddTask(string name, string description, DateTime dueDate)
    {
        Task task = new Task(name, description, dueDate);
        tasks.Add(task);
        SaveTasksToJson();
        Console.WriteLine("Task added successfully!");
    }

    public void ViewTasks()
    {
        int taskNumber = 1;
        foreach (Task task in tasks)
        {
            Console.WriteLine($"{taskNumber}. {task}");
            taskNumber++;
        }
    }

    public void MarkCompleted(int taskNumber)
    {
        if (taskNumber > 0 && taskNumber <= tasks.Count)
        {
            tasks[taskNumber - 1].IsCompleted = true;
            SaveTasksToJson();
            Console.WriteLine("Task marked as completed!");
        }
        else
        {
            Console.WriteLine("Invalid task number.");
        }
    }

    public void DeleteTask(int taskNumber)
    {
        if (taskNumber > 0 && taskNumber <= tasks.Count)
        {
            tasks.RemoveAt(taskNumber - 1);
            SaveTasksToJson();
            Console.WriteLine("Task deleted successfully!");
        }
        else
        {
            Console.WriteLine("Invalid task number.");
        }
    }

    private void SaveTasksToJson()
    {
        string json = JsonConvert.SerializeObject(tasks, Newtonsoft.Json.Formatting.Indented);
        File.WriteAllText(filePath, json);
    }

    public void LoadTasksFromJson()
    {
        if (File.Exists(filePath))
        {
            string json = File.ReadAllText(filePath);
            tasks = JsonConvert.DeserializeObject<List<Task>>(json);
        }
    }
}

