﻿using System;

class Program
{
    static void Main()
    {
        string filePath = "tasks.json"; 
        TaskManager taskManager = new TaskManager(filePath);
        taskManager.LoadTasksFromJson();

        int choice = 0;
        do
        {
            Console.WriteLine("---- Task Manager ----");
            Console.WriteLine("1. Add a Task");
            Console.WriteLine("2. View Tasks");
            Console.WriteLine("3. Mark Completed");
            Console.WriteLine("4. Delete Task");
            Console.WriteLine("5. Exit");
            Console.Write("Enter your choice: ");
            if (int.TryParse(Console.ReadLine(), out choice))
            {
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("---- Add a Task ----");
                        Console.Write("Enter Task Name: ");
                        string name = Console.ReadLine();
                        Console.Write("Enter Description: ");
                        string description = Console.ReadLine();
                        Console.Write("Enter Due Date (yyyy-mm-dd): ");
                        if (DateTime.TryParse(Console.ReadLine(), out DateTime dueDate))
                        {
                            taskManager.AddTask(name, description, dueDate);
                        }
                        else
                        {
                            Console.WriteLine("Invalid date format.");
                        }
                        break;

                    case 2:
                        Console.WriteLine("---- View Tasks ----");
                        taskManager.ViewTasks();
                        break;

                    case 3:
                        Console.WriteLine("---- Mark Completed ----");
                        Console.Write("Enter the task number to mark as completed: ");
                        if (int.TryParse(Console.ReadLine(), out int taskNumberToMark))
                        {
                            taskManager.MarkCompleted(taskNumberToMark);
                        }
                        else
                        {
                            Console.WriteLine("Invalid task number.");
                        }
                        break;

                    case 4:
                        Console.WriteLine("---- Delete Task ----");
                        Console.Write("Enter the task number to delete: ");
                        if (int.TryParse(Console.ReadLine(), out int taskNumberToDelete))
                        {
                            taskManager.DeleteTask(taskNumberToDelete);
                        }
                        else
                        {
                            Console.WriteLine("Invalid task number.");
                        }
                        break;

                    case 5:
                        Console.WriteLine("Exiting Task Manager...");
                        break;

                    default:
                        Console.WriteLine("Invalid choice.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Invalid choice. Please enter a number.");
            }

        } while (choice != 5);
    }
}

