﻿using System;

[Serializable] 
public class Task
{
    public string Name { get; set; }
    public string Description { get; set; }
    public DateTime DueDate { get; set; }
    public bool IsCompleted { get; set; }

    public Task(string name, string description, DateTime dueDate)
    {
        Name = name;
        Description = description;
        DueDate = dueDate;
        IsCompleted = false;
    }

    public override string ToString()
    {
        string status = IsCompleted ? "[Completed]" : "[Incomplete]";
        return $"{status} {Name} (Due: {DueDate.ToString("yyyy-MM-dd")})\nDescription: {Description}";
    }
}
